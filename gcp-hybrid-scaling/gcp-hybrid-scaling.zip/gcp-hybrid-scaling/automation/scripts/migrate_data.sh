#!/bin/bash
rsync -avz -e "ssh -i ~/.ssh/id_rsa" /var/www/html/ user@10.0.10.1:/var/www/html/