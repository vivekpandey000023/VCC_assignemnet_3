#!/bin/bash
sudo systemctl start prometheus
sudo systemctl enable prometheus